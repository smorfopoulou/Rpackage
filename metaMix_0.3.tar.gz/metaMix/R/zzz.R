### This idiom is now obsolete
#.First.lib <- function(libname, package) {
#  library.dynam("metaMix", package)
#}

.onLoad <- function(lib, pkg) {
# library.dynam("metaMix", package)
}


